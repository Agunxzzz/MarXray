#!/bin/bash
apt update && apt upgrade -y
mkdir /etc/xray
apt install socat -y
echo -e "$COLOR1┌─────────────────────────────────────────────────┐${NC}"
echo -e "$COLOR1│${NC}               • INPUT DOMAIN •                 ${NC} $COLOR1│$NC"
echo -e "$COLOR1└─────────────────────────────────────────────────┘${NC}"
read -rp "Input ur domain : " -e pp
    echo "$pp" > /etc/xray/domain 
echo "Silahkan pilih menu Gen-Cert untuk mendapatkan cert domain baru"
echo "Press any key to back on menu"
clear
domain=$(cat /etc/xray/domain)
Cek=$(lsof -i:80 | cut -d' ' -f1 | awk 'NR==2 {print $1}')
if [[ ! -z "$Cek" ]]; then
sleep 1
echo -e "[ ${red}WARNING${NC} ] Detected port 80 used by $Cek " 
systemctl stop $Cek
sleep 2
echo -e "[ ${GREEN}INFO${NC} ] Processing to stop $Cek " 
sleep 1
fi
echo -e "[ ${GREEN}INFO${NC} ] Starting renew gen-ssl... "
sleep 2
yum install curl socat -y
curl https://get.acme.sh | sh
~/.acme.sh/acme.sh --set-default-ca --server letsencrypt
~/.acme.sh/acme.sh --register-account -m resaananta42@gmail.com
~/.acme.sh/acme.sh --issue -d $domain --standalone
~/.acme.sh/acme.sh --installcert -d $domain --key-file /etc/xray/xray.key --fullchain-file /etc/xray/xray.crt

echo -e "[ ${GREEN}INFO${NC} ] Renew gen-ssl done... " 
sleep 2
echo -e "[ ${GREEN}INFO${NC} ] Starting service $Cek " 
sleep 2
echo -e "[ ${GREEN}INFO${NC} ] All finished... " 
sleep 0.5
sudo apt install nginx -y

mkdir /var/lib/marzban/backup
mv /var/lib/marzban/db.sqlite3 /var/lib/marzban/backup/db.sqlite3
mv /var/lib/marzban/xray_config.json /var/lib/marzban/backup/xray_config.json
mv db.sqlite3 /var/lib/marzban/db.sqlite3
mv xray_config.json /var/lib/marzban/xray_config.json
rm /etc/nginx/conf.d/xray.conf
mv xray.conf /etc/nginx/conf.d/xray.conf
service nginx restart
echo "silahkan ganti username dan pass"

